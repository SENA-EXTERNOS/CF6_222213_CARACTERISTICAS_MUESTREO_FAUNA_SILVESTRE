function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5phWzGIDzEg":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

